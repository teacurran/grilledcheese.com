Raver Goggles

12-12-98

COPYRIGHT 1998 TEA CALCIUM, ALL RIGHTS RESERVED

This font may not be altered or distribued in anyway without
express permission directly from TeA Calcium.

you may write to TeA at "tea@fucker.com"

If you like this font, perhaps you'll like 
my Other fonts, located at:

http://www.grilledcheese.com

If you make something neat with this font, please show me, I'm interested.

TeA Calcium
http://www.grilledcheese.com
tea@fucker.com
PO Box 2633
Taunton MA 02780