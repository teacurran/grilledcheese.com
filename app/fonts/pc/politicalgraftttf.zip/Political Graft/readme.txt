05.28.2001
Political Graft
GrilledCheese.com Freefont 

�copywrite 1997-2001 TeA Curran

This font is freeware. 
It may be used as much as you like, but never redistributed. 

If you want to give it to someone, give them the address to my site instead..   

http://www.grilledcheese.com/

thanks.

-TeA

tea@grilledcheese.com