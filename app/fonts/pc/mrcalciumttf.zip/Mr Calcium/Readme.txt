Mr Calcium.

This Font is an original work by TeA Calcium.
It can be downloaded from "http://www.grilledcheese.com".

This Font May NOT be redistributed to anyone for any reason. 

DO NOT REDISTRIBUTE THIS FONT, FUCKER.

You can use this font free of charge,
as long as you don't use it to advertise
canned meat products.
If you do use it to advertise canned meat,
you are required to send me 5 dollars.

Go here:   http://www.grilledcheese.com
And Here:  http://www.tacoland.com
Here Too:  http://www.chank.com/tea

Write to TeA at tea@fucker.com

Dont like the internet?

TeA Calcium
BOX 2633
Taunton MA 02780



this font is (c) Copyrite 1997-1998 Xone Zero Media