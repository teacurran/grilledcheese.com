MetroPass
(C) 1999 Grilledcheese Fonts, TeA Curran

This font can be found on the web at:
http://grilledcheese.com

This typeface is freeware for all personal use.
This license is issued to user at time of download 
and cannot be copied or transferred to persons 
other than the original licensee.

THIS FONT CANNOT BE REDISTRIBUTED, SOLD, OR GIVEN TO ANYONE.

-TeA
tea@fucker.com