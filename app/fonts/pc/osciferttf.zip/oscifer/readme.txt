hey look its a new font called oscifer..  
Font by TeA Calcium Febuary 1997..
Please do not distribute..    thats all.

oh yea, send me mail
tea@fucker.com

and stickers
i love stickers

and send me food
im hungry

http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
http://www.grilledcheese.com