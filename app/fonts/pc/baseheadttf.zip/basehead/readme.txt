Basehead Regular 2.0 
Created By TeA Curran 1997.  
(C) Copyright TeA Calcium, All rights reserved

I Created this font for My Zine Xandu, and because
I'm the nice guy that I am, Im giving It to You
For Free..  For Free You Say, Yep Free.  If you
want to be really nice you can send your comments,
or criticism of this Typeface, because well i'd
like to know what you think.

Send me something fun for this type and well call
it even...  and maybe youll get a catalog with 
stickers and something fun too.. 

TeA

Suck it...

Xone Zero

thats x as in zebra   

http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
http://www.grilledcheese.com
http://www.grilledcheese.com
 http://www.grilledcheese.com
  http://www.grilledcheese.com
   http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
    http://www.grilledcheese.com
   http://www.grilledcheese.com
  http://www.grilledcheese.com
 http://www.grilledcheese.com
