01.04.1998
Raver Kids
GrilledCheese.com Freefont 

�copywrite 1997-1999 TeA Curran

This font is freeware. 
It may be used as much as you like, but never redistributed. 

If you want to give it to someone, give them the address to my site instead..   

http://www.grilledcheese.com/

thanks.

drink some more milk

dont fuck with my copyrights.

or something.

be nice.

-TeA


TeA Curran
PO BOX 2633
Taunton MA 02780
tea@fucker.com 
